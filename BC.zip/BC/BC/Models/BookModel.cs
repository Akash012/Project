﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BC.Models
{
    public class BookModel : BookTable
    {
        //public int ID { get; set; }

        [Required]
        public string Name { get; set; }
        //public string ImageUrl { get; set; }
        public List<SelectListItem> Category { get; set; }
        //[Required]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Required]
        [Display(Name="Book Description")]
        public string BookDescription { get; set; }

        [Required]
        [Display(Name="Author Name")]
        public string AuthorName { get; set; }

        public int Quantity { get; set; }
    
        public int AvailableQuantity { get; set; }
        public int IssuedQuantity { get; set; }
        //public int BookCost { get; set; }
    }
}