﻿If the package is installed in an ASP.NET MVC 3 site, the site will not work.
If you’ve already installed the package into an MVC 3 application, uninstall it.

If the MVC 3 site does not work even after you have uninstalled the package, you might need to reinstall the ASP.NET MVC 3 packages as well.
