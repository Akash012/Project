﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;


namespace BC.Controllers
{
    public class AccountController : Controller
    {
        //
        // GET: /Account/

        //string constr = ConfigurationManager.ConnectionStrings["samsungsqlexpress"].ConnectionString;

        public ActionResult LogOn()
        {
            //using (SqlConnection con = new SqlConnection(constr))
            //{
            //    con.Open();
            //    con.Close();
            //}

            return View();
        }

        [HttpPost]
        public ActionResult LogOn(LogOnModel sp, string returnUrl)
        {
            Session.Add("LoginUserID", sp.MOBILEALIAS);

            if (ModelState.IsValid)
            {
                //if (!IsUserExistsInEntity(sp.MOBILEALIAS, sp.Location))
                //{
                //    ModelState.AddModelError("", "User Id does not exist for the currently selected location");
                //    sp = BindEntityScreenModel(sp);
                //}
                //else
                {
                    #region
                    using (UserDBEntities entities = new UserDBEntities())
                    {
                        aspnet_Users users = (from user in entities.aspnet_Users
                                              where user.UserName == sp.MOBILEALIAS
                                              select user).FirstOrDefault();
                        if (users == null)
                        {
                            ModelState.AddModelError("", "Enter Your user Id");
                        }
                        else
                        {
                            aspnet_Membership usermember = (from user in entities.aspnet_Membership
                                                            where user.UserId == users.UserId
                                                            select user).FirstOrDefault();

                            if (Membership.ValidateUser(users.UserName, sp.Password))
                            {
                                Session.Add("CurrentUser", users.UserName);

                                FormsAuthentication.RedirectFromLoginPage(users.UserName, false);
                                return RedirectToAction("Index", "Home");
                            }
                        }

                    }
                    #endregion
                }
                
            }
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to register the user
                MembershipCreateStatus createStatus;
                Membership.CreateUser(model.UserName, model.Password, model.Email, null, null, true, null, out createStatus);

                if (createStatus == MembershipCreateStatus.Success)
                {
                    FormsAuthentication.SetAuthCookie(model.UserName, false /* createPersistentCookie */);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "");
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }


        //
        // GET: /Account/ChangePassword

        [Authorize]
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Account/ChangePassword

        [Authorize]
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {

                // ChangePassword will throw an exception rather
                // than return false in certain failure scenarios.
                bool changePasswordSucceeded;
                try
                {
                    MembershipUser currentUser = Membership.GetUser(User.Identity.Name, true /* userIsOnline */);
                    changePasswordSucceeded = currentUser.ChangePassword(model.OldPassword, model.NewPassword);
                }
                catch (Exception)
                {
                    changePasswordSucceeded = false;
                }

                if (changePasswordSucceeded)
                {
                    return RedirectToAction("ChangePasswordSuccess");
                }
                else
                {
                    ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ChangePasswordSuccess

        public ActionResult ChangePasswordSuccess()
        {
            return View();
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();  
    return RedirectToAction("Index", "Home");  
        }  
       

    }
}