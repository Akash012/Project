﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Image.Models;
using System.IO;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Image.Controllers
{
    public class AdminController : Controller
    {
        private PracticeEntities db = new PracticeEntities();

        //
        // GET: /Default1/

        public ActionResult Index()
        {
            List<BookModel> bookmodel = new List<BookModel>();
            //Category category = new Category().T;
            List<BookTable> booktable = db.BookTables.Where(x => x.StatusId == 1 || x.StatusId == 3).ToList();
            foreach (var d in booktable)
            {
                BookModel pm = new BookModel();
                pm.ID = d.ID;
                pm.Name = d.Name;
                pm.AuthorName = d.AuthorName;
                pm.ImageUrl = d.ImageUrl;
                pm.CategoryName = db.Categories.Where(x => x.CategoryId == d.CategoryId).Select(x => x.CategoryName).FirstOrDefault();
                pm.BookDescription = d.BookDescription;
                pm.BookStatus = d.BookStatus;
                pm.Quantity = d.Quantity;
                pm.AvailableQuantity = d.AvailableQuantity;
                pm.IssueQuantity = d.IssueQuantity;
                pm.BookCost = d.BookCost;
                bookmodel.Add(pm);
            }
            return View(bookmodel);
        }

        //
        // GET: /Default1/Details/5

        public ActionResult Details(int id = 0)
        {
            BookTable booktable = db.BookTables.Find(id);
            if (booktable == null)
            {
                return HttpNotFound();
            }
            return View(booktable);
        }

        //
        // GET: /Default1/Create

        public ActionResult Create()
        {
            BookModel book = new BookModel();
            List<Category> category = new List<Category>();

            var list = (from data in db.Categories select data).ToList();

            foreach (var d in list)
            {
                Category pm = new Category();
                pm.CategoryId = d.CategoryId;
                pm.CategoryName = d.CategoryName;
                category.Add(pm);
            }
            book.Category = category;
            return View(book);
        }

        //
        // POST: /Default1/Create

        [HttpPost]
        public ActionResult Create(FormCollection fc, HttpPostedFileBase file)
        {
            BookTable booktable = new BookTable();
            var allowedExtensions = new[] { ".Jpg", ".png", ".jpg", ".jpeg" };

            var fileName = Path.GetFileName(file.FileName); //getting only file name(ex-ganesh.jpg)
            var ext = Path.GetExtension(file.FileName); //getting the extension (ex- .jpg)
            if (allowedExtensions.Contains(ext)) //check what type of extension
            {
                string name = Path.GetFileNameWithoutExtension(fileName);
                int id = 0;
                try
                {
                    id = (from s in db.BookTables select s.ID).Max();
                }
                catch (Exception ex) { }
                //booktable.Id = Convert.ToInt32(fc["Id"]);
                string myfile = "IMG-" + (id + 1) + ext; //appending the name with Id
                //store the file inside ~/project filder(Img)
                var path = Path.Combine(Server.MapPath("~/Img"), myfile);

                
                
                booktable.Name = fc["Name"].ToString();
                booktable.AuthorName = fc["AuthorName"].ToString();
                booktable.ImageUrl = "/Img/" + myfile; //getting complete url
                booktable.CategoryId = Convert.ToInt32(fc["CategoryId"]);
                booktable.BookDescription = fc["BookDescription"].ToString();
                //booktable.BookStatus = fc["BookStatus"].ToString();
                booktable.Quantity = Convert.ToInt32(fc["Quantity"]);
                booktable.AvailableQuantity = Convert.ToInt32(fc["AvailableQuantity"]);
                booktable.IssueQuantity = Convert.ToInt32(fc["IssueQuantity"]);
                booktable.BookCost = Convert.ToInt32(fc["BookCost"]);
                booktable.StatusId = 1;
                if (Convert.ToInt32(fc["AvailableQuantity"]) == 0)
                {
                    booktable.BookStatus = "Not Available";
                }
                else
                {
                    booktable.BookStatus = "Available";
                }
                
                //if (ModelState.IsValid)
                //{
                BooksLog bookslog = new BooksLog();
                    db.BookTables.Add(booktable);
                    db.SaveChanges();
                    file.SaveAs(path);
                    bookslog.ID = booktable.ID;
                    bookslog.ActionType = "Added";
                    bookslog.ActionDate = System.DateTime.Now;
                    bookslog.NewName = booktable.Name;
                    bookslog.NewAuthorName = booktable.AuthorName;
                    bookslog.NewCategoryId = booktable.CategoryId;
                    bookslog.NewQuantity = booktable.Quantity;
                    bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                    bookslog.NewIssueQuantity = booktable.IssueQuantity;
                    bookslog.NewBookCost = booktable.BookCost;
                    db.BooksLogs.Add(bookslog);
                    //db.Entry(bookslog).State = EntityState.Added;
                    
                    db.SaveChanges();
                    return RedirectToAction("Index");
                //}
            }
            else
            {
                ViewBag.message = "Please choose only Image file";
            }
            


               

                return View();
            
        }

        //
        // GET: /Default1/Edit/5

        public ActionResult Edit(int id = 0)
        {
            BookModel bookmodel = new BookModel();
            BookTable booktable = db.BookTables.Find(id);
            //BookTable olddata = (from s in db.BookTables where s.ID == bookmodel.ID select s).FirstOrDefault();
            HttpContext.Session.Add("OldData", booktable);
            if (booktable == null)
            {
                return HttpNotFound();
            }
            else
            {
                List<Category> category = new List<Category>();

                var list = (from data in db.Categories select data).ToList();

                foreach (var d in list)
                {
                    Category pm = new Category();
                    pm.CategoryId = d.CategoryId;
                    pm.CategoryName = d.CategoryName;
                    category.Add(pm);
                }
                bookmodel.Category = category;
                bookmodel.ID = booktable.ID;
                bookmodel.Name = booktable.Name;
                bookmodel.AuthorName = booktable.AuthorName;
                bookmodel.ImageUrl = booktable.ImageUrl;
                bookmodel.CategoryId = booktable.CategoryId;
                bookmodel.BookDescription = booktable.BookDescription;
                bookmodel.BookStatus = booktable.BookStatus;
                bookmodel.Quantity = booktable.Quantity;
                bookmodel.AvailableQuantity = booktable.AvailableQuantity;
                bookmodel.IssueQuantity = booktable.IssueQuantity;
                bookmodel.BookCost = booktable.BookCost;
                
               
            }
            return View(bookmodel);
        }

        //
        // POST: /Default1/Edit/5

        [HttpPost]
        public ActionResult Edit(FormCollection fc, HttpPostedFileBase file, BookModel bookmodel)
        {
            BooksLog bookslog = new BooksLog();
             BookTable booktable = new BookTable();
             BookTable olddata = Session["OldData"] as BookTable;
            
            //string imgname = (from s in db.BookTables
            //                 where s.Id == bookmodel.Id
            //               select s.FileName).FirstOrDefault();
            //if (System.IO.File.Exists(Server.MapPath(@"~\Image\Img\" + imgname)))
            //{
            //    System.IO.File.Delete(Server.MapPath(@"~\Image\Img\" + imgname));
            //}
             try
             {
                 if (!string.IsNullOrEmpty(file.FileName) && !string.IsNullOrWhiteSpace(file.FileName) && file.FileName != "")
                 {
                     var allowedExtensions = new[] { ".Jpg", ".png", ".jpg", ".jpeg" };

                     var fileName = Path.GetFileName(file.FileName); //getting only file name(ex-ganesh.jpg)
                     var ext = Path.GetExtension(file.FileName); //getting the extension (ex- .jpg)
                     if (allowedExtensions.Contains(ext)) //check what type of extension
                     {
                         string name = Path.GetFileNameWithoutExtension(fileName);
                         booktable.ID = Convert.ToInt32(fc["Id"]);
                         string myfile = "IMG-" + booktable.ID + ext;
                         var path = Path.Combine(Server.MapPath("~/Img"), myfile);
                         booktable.ImageUrl = "/Img/" + myfile;
                         file.SaveAs(path);
                     }
                 }
             }
             catch(Exception)
             {
                 booktable.ImageUrl = olddata.ImageUrl;
             }
                booktable.ID = Convert.ToInt32(fc["Id"]);
                booktable.Name = fc["Name"].ToString();
                booktable.AuthorName = fc["AuthorName"].ToString();
                booktable.CategoryId = Convert.ToInt32(fc["CategoryId"]);
                booktable.BookDescription = fc["BookDescription"].ToString();
                //booktable.BookStatus = fc["BookStatus"];
                booktable.Quantity = Convert.ToInt32(fc["Quantity"]);
                booktable.AvailableQuantity = Convert.ToInt32(fc["AvailableQuantity"]);
                booktable.IssueQuantity = Convert.ToInt32(fc["IssueQuantity"]);
                booktable.BookCost = Convert.ToInt32(fc["BookCost"]);
                booktable.StatusId = 3;
                if (Convert.ToInt32(fc["AvailableQuantity"]) == 0)
                {
                    booktable.BookStatus = "Not Available";
                }
                else
                {
                    booktable.BookStatus = "Available";
                }
                if (ModelState.IsValid)
                {
                   
                    db.Entry(booktable).State = EntityState.Modified;
                    //db.Configuration.ValidateOnSaveEnabled = false;
                    db.SaveChanges();
                    bool IsEdited = false;
                    bookslog.ID = booktable.ID;
                    bookslog.ActionType = "Edited";
                    bookslog.ActionDate = System.DateTime.Now;
                    if (booktable.Name == olddata.Name)
                    {
                        bookslog.NewName = "NAN";
                        bookslog.OldName = olddata.Name;
                    }
                    else
                    {
                        bookslog.NewName = booktable.Name;
                        bookslog.OldName = olddata.Name;
                        IsEdited = true;
                    }
                    //bookslog.NewName = booktable.Name;
                    //bookslog.OldName = olddata.Name;
                    if (booktable.AuthorName == olddata.AuthorName)
                    {
                        bookslog.NewAuthorName = "NAN";
                        bookslog.OldAuthorName = olddata.AuthorName;
                    }
                    else
                    {
                        bookslog.NewAuthorName = booktable.AuthorName;
                        bookslog.OldAuthorName = olddata.AuthorName;
                        IsEdited = true;
                    }
                    if (booktable.CategoryId == olddata.CategoryId)
                    {
                        bookslog.OldCategoryId = olddata.CategoryId;
                    }
                    else
                    {
                        bookslog.NewCategoryId = booktable.CategoryId;
                        bookslog.OldCategoryId = olddata.CategoryId;
                        IsEdited = true;
                    }
                    //bookslog.NewCategoryId = booktable.CategoryId;
                    //bookslog.OldCategoryId = olddata.CategoryId;
                    if (booktable.BookDescription == olddata.BookDescription)
                    {
                        bookslog.NewBookDescription = "NAN";
                        bookslog.OldBookDescription = olddata.BookDescription;
                    }
                    else
                    {
                        bookslog.NewBookDescription = booktable.BookDescription;
                        bookslog.OldBookDescription = olddata.BookDescription;
                        IsEdited = true;
                    }
                    if (booktable.Quantity == olddata.Quantity)
                    {
                        bookslog.OldQuantity = olddata.Quantity;
                    }
                    else
                    {
                        bookslog.NewQuantity = booktable.Quantity;
                        bookslog.OldQuantity = olddata.Quantity;
                        IsEdited = true;
                    }
                    //bookslog.NewQuantity = booktable.Quantity;
                    //bookslog.OldQuantity = olddata.Quantity;
                    if (booktable.AvailableQuantity == olddata.AvailableQuantity)
                    {
                        bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                    }
                    else
                    {
                        bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                        bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                        IsEdited = true;
                    }
                    //bookslog.NewAvailableQuantity = booktable.AvailableQuantity;
                    //bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
                    if (booktable.IssueQuantity == olddata.IssueQuantity)
                    {
                        bookslog.OldIssueQuantity = olddata.IssueQuantity;
                    }
                    else
                    {
                        bookslog.NewIssueQuantity = booktable.IssueQuantity;
                        bookslog.OldIssueQuantity = olddata.IssueQuantity;
                        IsEdited = true;
                    }
                    //bookslog.NewIssueQuantity = booktable.IssueQuantity;
                    //bookslog.OldIssueQuantity = olddata.IssueQuantity;
                    if (booktable.BookCost == olddata.BookCost)
                    {
                        bookslog.OldBookCost = olddata.BookCost;
                    }
                    else
                    {
                        bookslog.NewBookCost = booktable.BookCost;
                        bookslog.OldBookCost = olddata.BookCost;
                        IsEdited = true;
                    }
                    //bookslog.NewBookCost = booktable.BookCost;
                    //bookslog.OldBookCost = olddata.BookCost;
                    //System.Web.UI.ScriptManager script_manager = new System.Web.UI.ScriptManager();
                    if (IsEdited == true)
                    {
                        db.BooksLogs.Add(bookslog);
                        db.Entry(bookslog).State = EntityState.Added;
                        db.SaveChanges();
                        //ViewData["Message"] = "bijbkbwk";
                        HttpContext.Session.Add("Message", "Data save sucessfully");
                        //ViewBag.Message = string.Format("Your Data is Saved Sucessfully");
                        //script_manager.Page.ClientScript.RegisterStartupScript(this.GetType(), "alertMessage", "alert('Change Data Sucessfully.');", true);
                        //ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Only alert Message');", true);

                    }
                    else
                    {
                        //ViewData["Message"] = "aaaaaaaaa";
                        HttpContext.Session.Add("Message","Data save sucessfully");
                        //ViewBag.Message = string.Format("Your Data is not Saved Sucessfully");
                       // script_manager.Page.ClientScript.RegisterStartupScript(this.GetType(), "alertMessage", "alert('No Changes Done.');", true);
                   }
                    HttpContext.Session.Remove("OldData");
                    return RedirectToAction("Index");
                }
             return View(bookmodel);
        }

        //
        // GET: /Default1/Delete/5

        public ActionResult Delete(int id = 0)
        {
            BookTable booktable = db.BookTables.Find(id);
            HttpContext.Session.Add("OldData", booktable);
            if (booktable == null)
            {
                return HttpNotFound();
            }
            return View(booktable);
        }

        //
        // POST: /Default1/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            BooksLog bookslog = new BooksLog();
            BookTable booktable = db.BookTables.Find(id);
            BookTable olddata = Session["OldData"] as BookTable;
            booktable.StatusId = 2;
            //db.BookTables.Remove(booktable);
            bookslog.ID = booktable.ID;
            bookslog.ActionType = "Deleted";
            bookslog.ActionDate = System.DateTime.Now;
            bookslog.OldName = olddata.Name;
            bookslog.OldAuthorName = olddata.AuthorName;
            bookslog.OldCategoryId = olddata.CategoryId;
            bookslog.OldBookDescription = olddata.BookDescription;
            bookslog.OldQuantity = olddata.Quantity;
            bookslog.OldAvailableQuantity = olddata.AvailableQuantity;
            bookslog.OldIssueQuantity = olddata.IssueQuantity;
            bookslog.OldBookCost = olddata.BookCost;
            //db.SaveChanges();
            
            db.BooksLogs.Add(bookslog);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}