﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Image.Models
{
    public class BookModel : BookTable
    {
        //public int ID { get; set; }

        [Required]
        public string Name { get; set; }
        //public string ImageUrl { get; set; }
        public List<Category> Category { get; set; }

        [Display(Name="Category Name")]
        public string CategoryName { get; set; }

        //public string BookStatus { get; set; }
        public int Quantity { get; set; }
    
        public int AvailableQuantity { get; set; }
        public int IssuedQuantity { get; set; }
        //public int BookCost { get; set; }
    }
}