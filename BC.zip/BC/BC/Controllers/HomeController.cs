﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BC.Models;
using System.IO;

namespace BC.Controllers
{
    public class HomeController : Controller
    {
        UserDBEntities obj = new UserDBEntities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
           
            return View();
        }

       public ActionResult Image()
        {
            List<BookModel> model = new List<BookModel>();

            var details = (from data in obj.BookTables select data).ToList();

            foreach (var d in details)
            {
                BookModel pm = new BookModel();
                pm.ID = d.ID;
                pm.ImageUrl = d.ImageUrl;
                pm.Name = d.Name;
                model.Add(pm);
            }

            return View(model);
           
        }
        public ActionResult Cart()
        {
            return View();
        }

        public ActionResult Order()
        {
            return View();
        }

        public ActionResult Popular()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult RentIt()
        {
            return View();
        }

    }
}
