﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BC.Models
{
    public class CartModel : CartTable
    {
        public int RefNoId { get; set; }
        public aspnet_Users aspnet_Users { get; set; }
        public string UserName { get; set; }
        public BookTable BookTable { get; set; }
        public int Id { get; set; }
        public int NoOfQuantity { get; set; }
    }
}