﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Image.Models;
using System.IO;

namespace Image.Controllers
{
    public class HomeController : Controller
    {
        PracticeEntities obj = new PracticeEntities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
           
            return View();
        }

        //[HttpPost]
        //public ActionResult Index (FormCollection fc, HttpPostedFileBase file)
        //{
        //    BookTable profile = new BookTable();
        //    var allowedExtensions = new[] { ".Jpg", ".png", ".jpg", ".jpeg" };
           
        //    var fileName = Path.GetFileName(file.FileName); //getting only file name(ex-ganesh.jpg)
        //    var ext = Path.GetExtension(file.FileName); //getting the extension (ex- .jpg)
        //    if (allowedExtensions.Contains(ext)) //check what type of extension
        //    {
        //        string name = Path.GetFileNameWithoutExtension(fileName);
        //        profile.Id = Convert.ToInt32(fc["Id"]);
        //        string myfile = "IMG-" + profile.Id + ext; //appending the name with Id
        //        //store the file inside ~/project filder(Img)
        //        var path = Path.Combine(Server.MapPath("~/Img"),myfile);
               
        //        profile.ImageUrl = "/Img/"+ myfile; //getting complete url
        //        profile.Name = fc["Name"].ToString();
        //        obj.Profiles.Add(profile);
        //        obj.SaveChanges();
        //        file.SaveAs(path);
        //    }

        //    else
        //    {
        //        ViewBag.message = "Please choose only Image file";
        //    }
        //    return View();
        //}

        public ActionResult Image()
        {
            List<BookModel> model = new List<BookModel>();

            var details = (from data in obj.BookTables select data).ToList();

            foreach (var d in details)
            {
                BookModel pm = new BookModel();
                pm.ID = d.ID;
                pm.ImageUrl = d.ImageUrl;
                pm.Name = d.Name;
                model.Add(pm);
            }

            return View(model);
           
        }
        public ActionResult Cart()
        {
            return View();
        }

        public ActionResult Order()
        {
            return View();
        }

        public ActionResult Popular()
        {
            return View();
        }

    }
}
