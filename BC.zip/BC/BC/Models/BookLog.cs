﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BC.Models
{
    public class BookLog : BooksLog
    {
        public int AuditId { get; set; }

        public List<BookTable> Booktable { get; set; }
        [Required]
        public string BookName { get; set; }

        public List<BookStatu> BookStatus { get; set; }
        [Required]
        public string ActionType { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime ActionDate { get; set; }

        public IEnumerable<BooksLog> BookLogList { get; set; }

        //public string OldName { get; set; }
        //public string NewName { get; set; }
        public List<Category> Category { get; set; }
        public string OldCategoryName { get; set; }
        public string NewCategoryName { get; set; }

        public string OldAuthorName { get; set; }
        public string NewAuthorName { get; set; }
        public string OldBookDescription { get; set; }
        public string NewBookDescription { get; set; }
        //public Nullable<int> OldIssueQuantity { get; set; }
        //public Nullable<int> NewIssueQuantity { get; set; }
        //public Nullable<int> OldBookCost { get; set; }
        //public Nullable<int> NewBookCost { get; set; }
       
    }
}