window.onload = function(){
  // Buttons
  var quickAddBtn = document.getElementById('QuickAdd');
  var quickAddFormDiv = document.querySelector('.quickaddForm')
  var cancelBtn = document.getElementById('Cancel');
  var AddBtn = document.getElementById('Add');

  // Form Fields
  var fullname = document.getElementById('fullname');
  var phone = document.getElementById('phone');
  // Divs etc.
  var addDicDiv = document.querySelector('.adddic');

  quickAddBtn.addEventListener("click", function(){
    // display the form div
    quickAddFormDiv.style.display = "block";
    addDicDiv.style.display = 'none';
  });

  cancelBtn.addEventListener("click", function(){
    quickAddFormDiv.style.display = "none";
    addDicDiv.style.display = "block";
          });

  AddBtn.addEventListener("click", addToDic);

  // AddBtn.addEventListener("click", function(){
  //   addDicDiv.style.display = "block";
  // });

   AddBtn.addEventListener("click", function(){
    
      quickAddFormDiv.style.display = "block";
    
    function timedRefresh(timeoutPeriod) {
    setTimeout("location.reload(true);",timeoutPeriod);
}

window.onload = timedRefresh(0.00001);

  });

  addDicDiv.addEventListener("click", removeEntry);

  // Storage Array
  var phoneDic = [];


  function jsonStructure(fullname,phone){
    this.fullname = fullname;
    this.phone = phone;
  }


  function addToDic(){
    var isNull = fullname.value!='' && phone.value!='';
    if(isNull){
      // format the input into a valid JSON structure
      var obj = new jsonStructure(fullname.value,phone.value);
      phoneDic.push(obj);
      localStorage['addDic'] = JSON.stringify(phoneDic);
      quickAddFormDiv.style.display = "none";
      clearForm();
      showPhoneDic();
    }
  }

  function removeEntry(e){
    // Remove an entry from the PhoneDirectory
var result = confirm("Are you Sure!!!"); ///<-- Confirmation Before Deleting
if (result){
    if(e.target.classList.contains('delbutton')){
      var remID = e.target.getAttribute('data-id');
      phoneDic.splice(remID,1);
      localStorage['addDic'] = JSON.stringify(phoneDic);
      showPhoneDic();
      }
    }
  }


  function clearForm(){
    var formFields = document.querySelectorAll('.formFields');
    for(var i in formFields){
      formFields[i].value = '';
    }
  }

  function showPhoneDic(){
    if(localStorage['addDic'] === undefined){
      localStorage['addDic'] = '';
    } else {
      phoneDic = JSON.parse(localStorage['addDic']);
      // Loop over the array addressBook and insert into the page
      addDicDiv.innerHTML = '<table style="width: 60%"><tr>'
       + '<th>Name</th> <th>PhoneNumber</th> <th>Delete</th>'+ '</tr> </table> ';
      for(var n in phoneDic){
        var str = '<table><tr class="entry">';
          str += '<td class="name">' + phoneDic[n].fullname + '</td>';
          str += '<td class="phone"><p>' + phoneDic[n].phone + '</td>';
          str += '<td class="del"><a href="#" class="delbutton" data-id="' + n + '">Delete</a></td>';
          str += '</tr> </table>';
        addDicDiv.innerHTML += str;
      }
    }
  }

  showPhoneDic();

       //input display sametime
       var inputBox = document.getElementById('fullname');
var inputBox1 = document.getElementById('phone');
inputBox.onkeyup = function(){
    document.getElementById('printdisplaybox').innerHTML = "Your Typing: <br>" + inputBox.value;
}
inputBox1.onkeyup = function(){
    document.getElementById('printdisplaybox1').innerHTML = "<br>" + inputBox1.value;
}


}