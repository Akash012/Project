﻿using Image.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Image.ViewModel
{
    public class BookLogVM
    {
        public BooksLog booklog { get; set; }
        public List<BookTable> booktable { get; set; }
        public List<BookStatu> bookstatus { get; set; }
    }
}