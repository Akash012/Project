﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BC.Controllers
{
    public class BooksController : Controller
    {
        //
        // GET: /Books/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Action_Adventure()
        {
            ViewBag.Message = "This is AA Page";

            return View();
        }

        public ActionResult Romance()
        {
            ViewBag.Message = "This is R Page";

            return View();
        }

        public ActionResult Biographies()
        {
            ViewBag.Message = "This is B PAge";

            return View();
        }

        public ActionResult Historical_Fiction()
        {
            ViewBag.Message = "This is HF Page";

            return View();
        }

        public ActionResult Sci_fi()
        {
            ViewBag.Message = "This is SF Page";

            return View();
        }
        public ActionResult RentIt()
        {
            ViewBag.Message = "Your Rent it Cart.";

            return View();
        }
    }
}
